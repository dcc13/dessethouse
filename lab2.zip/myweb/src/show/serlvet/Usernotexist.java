package show.serlvet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Usernotexist
 */
@WebServlet("/Usernotexist")
public class Usernotexist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Usernotexist() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		ServletContext Context= getServletContext();
			int sumofpeople = Integer.parseInt((String) Context.getAttribute("sumofpeople"));
	    	int sumoflogin = Integer.parseInt((String) Context.getAttribute("sumoflogin"));
	    	int sumofcus = Integer.parseInt((String) Context.getAttribute("sumofcus"));
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>error</title></head>");
		out.println("<dody>");
		out.println("<p>用户不存在或密码错误</p>");
		 out.println("总访问人数:"+sumofpeople);
	     out.println("已登录人数"+sumoflogin);
	     out.println("游客人数"+sumofcus);
		out.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
