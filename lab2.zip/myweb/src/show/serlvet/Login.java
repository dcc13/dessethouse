package show.serlvet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		System.out.println("is  logining -------");
			ServletContext Context= getServletContext();
			int sumofpeople = Integer.parseInt((String) Context.getAttribute("sumofpeople"));
	    	int sumoflogin = Integer.parseInt((String) Context.getAttribute("sumoflogin"));
	    	int sumofcus = Integer.parseInt((String) Context.getAttribute("sumofcus"));
		//	int pageCounter= Integer.parseInt((String) Context.getAttribute("pageCounter"));
			if (null == request.getParameter("Logout")) {
				//System.out.println(pageCounter++);
				sumofpeople++;
			//	sumoflogin++;
				Context.setAttribute("sumofpeople", Integer.toString(sumofpeople));
				
				
		//		Context.setAttribute("pageCounter", Integer.toString(pageCounter));
			}
        request.setCharacterEncoding("utf-8");
			String login="";
			String password="";
			HttpSession session = request.getSession(false);
			Cookie cookie = null;
	        Cookie[] cookies = request.getCookies();
	  
	        Integer ival = new Integer(1);
	        		
	        if (null != cookies) {
	            // Look through all the cookies and see if the
	            // cookie with the login info is there.
	            for (int i = 0; i < cookies.length; i++) {
	                cookie = cookies[i];
	                if (cookie.getName().equals("LoginCookieUser")) {
	                    login=cookie.getValue();
	                
	                    break;
	                }
	                
	            }
	            for(int i=0;i<cookies.length;i++){
	            	cookie=cookies[i];
	            	if(cookie.getName().equals("LoginCookiePassword")){
	            		password=cookie.getValue();
	            		break;
	            	}
	            
	            }
	        }
	    
	        // Logout action removes session, but the cookie remains
	        if (null != request.getParameter("Logout")) {
	            if (null != session) {
	            	session.invalidate();
	                session = null;
	            }
	            sumoflogin--;
	            Context.setAttribute("sumoflogin", Integer.toString(sumoflogin));
	            sumofcus++;
	            Context.setAttribute("sumofcus", Integer.toString(sumofcus));
	            
	            
	        }
	       
	        response.setContentType("text/html; charset=utf-8");
	        PrintWriter out = response.getWriter();
	        out.println("<html><body>");
	        out.println(
	            "<form method='POST' action='"
	                + response.encodeURL(request.getContextPath()+"/Loginjustify")
	                + "'>");
	        out.println(
	            "login: <input type='text' name='login' value='" + login + "'>");
	        out.println(
	            "password: <input type='password' name='password' value='"+password+"'>");
	        out.println("<input type='submit' name='Submit' value='Submit'>");
	        out.println("总访问人数:"+sumofpeople);
	        out.println("已登录人数"+sumoflogin);
	             out.println("游客人数"+sumofcus);
	   //     out.println("</p>You are visitor number " + pageCounter);
	       
	        out.println("</form></body></html>");
	        
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
	}

}
