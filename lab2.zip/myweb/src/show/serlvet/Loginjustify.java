package show.serlvet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import show.model.Homework;


/**
 * Servlet implementation class Loginjustify
 */
@WebServlet("/Loginjustify")
public class Loginjustify extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DataSource datasource = null; 
	private HttpSession session=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Loginjustify() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void init(){
		InitialContext jndiContext = null;
		
		Properties properties = new Properties();
		properties.put(javax.naming.Context.PROVIDER_URL, "jnp:///");
		properties.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
				"org.apache.naming.java.javaURLContextFactory");
		try {
			jndiContext = new InitialContext(properties);
			datasource = (DataSource) jndiContext
					.lookup("java:comp/env/jdbc/abcdefds");
			System.out.println("got context");
			System.out.println("About to get ds---justifyuser");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		processRequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
		processRequest(request,response);
	}
	/*private void processRequest(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		System.out.println(req.getParameter("login"));
	}
	*/
	private void processRequest(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {

				session = req.getSession(false);
				int cookieFound = -1;
				boolean cookiePaFound=false;
				String password=req.getParameter("password");
				System.out.println(req.getParameter("login") +" req");
				System.out.println(req.getParameter("password"));
				Cookie cookie = null;
				Cookie pcookie=null;
				Cookie[] cookies = req.getCookies();
				if (null != cookies) {
					// Look through all the cookies and see if the
					// cookie with the login info is there.
					for (int i = 0; i < cookies.length; i++) {
						cookie = cookies[i];
						if (cookie.getName().equals("LoginCookieUser")) {
							
							cookieFound++;
							break;
						}
					}
					for(int i=0;i<cookies.length;i++){
		            	pcookie=cookies[i];
		            	if(pcookie.getName().equals("LoginCookiePassword")){
		            	//	password=pcookie.getValue();
		            		cookieFound++;
		            		break;
		            	}
		            
		            }
					
					
				}

				if (session == null) {
					String loginValue = req.getParameter("login");
					String loginPass=req.getParameter("password");
					boolean isLoginAction = (null == loginValue) ? false : true;
					//判断之前是否访问过
				//	Integer ival = new Integer(1);
					System.out.println(loginValue +"seesion null");
					if (isLoginAction) { // User is logging in
						if (cookieFound==1) { // If the cookie exists update the value only
						// if changed
							if (!loginValue.equals(cookie.getValue())) {
								cookie.setValue(loginValue);
								resp.addCookie(cookie);
							}
							if(!loginPass.equals(pcookie.getValue())){
								pcookie.setValue(loginPass);
								resp.addCookie(pcookie);
							}
						} else {
							// If the cookie does not exist, create it and set value
							cookie = new Cookie("LoginCookieUser", loginValue);
							
							cookie.setMaxAge(Integer.MAX_VALUE);
							pcookie=new Cookie("LoginCookiePass",loginPass);
							pcookie.setMaxAge(Integer.MAX_VALUE);
							
							// System.out.println("Add cookie");
							resp.addCookie(cookie);
							resp.addCookie(pcookie);
						}

						// create a session to show that we are logged in
						session = req.getSession(true);
						session.setAttribute("login", loginValue);
						session.setAttribute("password", loginPass);
						//session.setAttribute("sessiontest.counter", ival);
					//	req.setAttribute("sessiontest.counter", ival);
						req.setAttribute("login", loginValue);
						req.setAttribute("password", password);
                        justifyUser(req,resp);
						//getStockList(req, resp);
					//	session.setAttribute("listStock",req.getAttribute("list"));
					//	resp.sendRedirect("/onlinestockWeb/MyStockList");
						
					} else {
						System.out.println(loginValue +"seesion null");
						// Display the login page. If the cookie exists, set login
						resp.sendRedirect(req.getContextPath() + "/Login");
					}
				} else {
				//	Integer ival = (Integer) session
						//	.getAttribute("sessiontest.counter");
				//	if(ival!=null )  //��**.jspҳ��ת��������������Ϊ**.jspҳ�洴����session����ִ�������if(session==null)���
					//	ival = new Integer(ival.intValue() + 1);
				//	session.setAttribute("sessiontest.counter", ival);

					String loginValue = (String) session.getAttribute("login");
					String loginPass=(String)session.getAttribute("password");
					System.out.println(loginValue +" session");
					if(loginValue==null || loginValue!=req.getParameter("login")){
						System.out.println(loginValue +" null or old login");
						loginValue = req.getParameter("login");
						System.out.println(loginValue +" request");
						session.setAttribute("login",loginValue  );
					
					}
					if(loginPass==null||loginPass!=req.getParameter("password")){
					    System.out.println(loginPass+"old");
					    loginPass=req.getParameter("password");
					    session.setAttribute("password", loginPass);
					}
					req.setAttribute("login", loginValue);
					req.setAttribute("password", password);
				//	req.setAttribute("sessiontest.counter", ival);
					
					justifyUser(req, resp);
				//	session.setAttribute("listStock",req.getAttribute("list"));
//					displayLogoutPage(req, resp);
				//	resp.sendRedirect("/onlinestockWeb/MyStockList");
				}

			}
	public void justifyUser(HttpServletRequest req,
			HttpServletResponse res){
		System.out.println("is  justifying usering-------");
		ServletContext Context= getServletContext();
	//	int sumofpeople = Integer.parseInt((String) Context.getAttribute("sumofpeople"));
    	int sumoflogin = Integer.parseInt((String) Context.getAttribute("sumoflogin"));
    	int sumofcus = Integer.parseInt((String) Context.getAttribute("sumofcus"));
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet result = null;
		ArrayList list = new ArrayList();
//		StockListBean listStock = new StockListBean();		
		try {
			connection = datasource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}  	
		
		try {
			stmt = connection.prepareStatement("select * from userlist where username=? and password=?");
			System.out.println((String) req.getAttribute("login"));
			System.out.println((String) req.getAttribute("password"));
			
			stmt.setString(1, (String) req.getAttribute("login"));
			stmt.setString(2, (String) req.getAttribute("password"));
			result = stmt.executeQuery();
			if(result.next()){
				sumoflogin++;
				Context.setAttribute("sumoflogin",Integer.toString(sumoflogin));
				System.out.println("userexist");
				getHomeworkList(req,res);
				session.setAttribute("homeworklist",req.getAttribute("list"));
				try {
					res.sendRedirect(req.getContextPath()+"/Showhomeworklist");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				sumofcus++;
				Context.setAttribute("sumofcus", Integer.toString(sumofcus));
			    System.out.println("usernotexist");
			    try {
					res.sendRedirect(req.getContextPath()+"/Usernotexist");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
//			listStock.setStockList(list);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
	public void getHomeworkList(HttpServletRequest req,
			HttpServletResponse res){
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet result = null;
		ArrayList list = new ArrayList();
//		StockListBean listStock = new StockListBean();		
		try {
			connection = datasource.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}  	
		try {
			stmt = connection.prepareStatement("select * from homework where username=?");
			System.out.println(req.getAttribute("login"));
			stmt.setString(1, (String) req.getAttribute("login"));
			result = stmt.executeQuery();
			while (result.next()) {
				Homework homework=new Homework();
			//	System.out.println(result.getString(1));
				homework.setUsername(result.getString(1));
			//	System.out.println(result.getString(2));
				homework.setCoursename(result.getString(2));
				homework.setHomeworkname(result.getString(3));
			//	System.out.println(result.getString(3));
				homework.setComplete(result.getBoolean(4));
			//	System.out.println(result.getBoolean(4));
				homework.setGrade(result.getDouble(5));
			//	System.out.println(result.getDouble(5));
				list.add(homework);
				
		
				
	
	     }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		req.setAttribute("list", list);

	}
	}
		/*	public void getStockList(HttpServletRequest req,
					HttpServletResponse res){
				
				Connection connection = null;
				PreparedStatement stmt = null;
				ResultSet result = null;
				ArrayList list = new ArrayList();
//				StockListBean listStock = new StockListBean();		
				try {
					connection = datasource.getConnection();
				} catch (SQLException e) {
					e.printStackTrace();
				}  	
				
				try {
					stmt = connection.prepareStatement("select stockid from mystock where userid=?");
					stmt.setString(1, (String) req.getAttribute("login"));
					result = stmt.executeQuery();
					while (result.next()) {
						Stock stock = new Stock();
						stock.setId(result.getInt("stockid"));
			/*			stock.setCompanyName(result.getString(2));
						stock.setType(result.getString(3));
						stock.setPrice(result.getDouble(4));  
						stock.setDate(result.getDate("date"));*/
			/*			list.add(stock);
					}
//					listStock.setStockList(list);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				req.setAttribute("list", list);

			}
	*/
