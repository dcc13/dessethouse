package show.serlvet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import show.model.Homework;

/**
 * Servlet implementation class Showhomeworklist
 */
@WebServlet("/Showhomeworklist")
public class Showhomeworklist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Showhomeworklist() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		justfiyhomework(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
		justfiyhomework(request, response);
	}
	public void displayhomework(HttpServletRequest req,
			HttpServletResponse res) throws IOException {
		ServletContext Context= getServletContext();
		int sumofpeople = Integer.parseInt((String) Context.getAttribute("sumofpeople"));
    	int sumoflogin = Integer.parseInt((String) Context.getAttribute("sumoflogin"));
    	int sumofcus = Integer.parseInt((String) Context.getAttribute("sumofcus"));
		HttpSession session = req.getSession(false);
		ArrayList list = (ArrayList) session.getAttribute("homeworklist");
	//	Integer pageCounter = (Integer) session.getAttribute("sessiontest.counter");
		String loginValue =(String) session.getAttribute("login");
		
		res.setContentType("text/html;charset=utf-8");
		PrintWriter out = res.getWriter();
		out.println("<html><body>");
		
		out.println("<table width='650' border='0' >");
		
		out.println("</table>");
		
		out.println("<p>Welcome " + loginValue + "</p>");
		out.println("<form method='GET' action='"
				+ res.encodeURL(req.getContextPath() + "/Login") + "'>");
		
		for (int i = 0; i < list.size(); i++) {
			Homework homework = (Homework) list.get(i);
			out.println("<p>");
			out.println(homework.getCoursename()+";");
			out.println(homework.getHomeworkname()+";");
			out.println("完成;");
			out.println(homework.getGrade());
			out.println("</p>");

		}

		out.println("<input type='submit' name='Logout' value='Logout'>");
		out.println("</form>");

		out.println("总访问人数:"+sumofpeople);
	     out.println("已登录人数"+sumoflogin);
	     out.println("游客人数"+sumofcus);
		out.println("</body></html>");

	}
	public void justfiyhomework(HttpServletRequest req,
			HttpServletResponse res) throws IOException {
		ServletContext Context= getServletContext();
		int sumofpeople = Integer.parseInt((String) Context.getAttribute("sumofpeople"));
    	int sumoflogin = Integer.parseInt((String) Context.getAttribute("sumoflogin"));
    	int sumofcus = Integer.parseInt((String) Context.getAttribute("sumofcus"));
		HttpSession session = req.getSession(false);
		ArrayList list = (ArrayList) session.getAttribute("homeworklist");
	//	Integer pageCounter = (Integer) session.getAttribute("sessiontest.counter");
     String loginValue =(String) session.getAttribute("login");
		int uncomplete=0;
		res.setContentType("text/html;charset=utf-8");
		PrintWriter out = res.getWriter();
		out.println("<html><body>");
		out.println("<p>Welcome " + loginValue + "</p>");
		out.println("<form method='GET' action='"
				+ res.encodeURL(req.getContextPath() + "/Login") + "'>");
		for (int i = 0; i < list.size(); i++) {
			Homework homework = (Homework) list.get(i);
			boolean complete=homework.getComplete();
			if(!complete){
				uncomplete++;
				out.println("<p>");
				out.println(homework.getCoursename()+":"+homework.getHomeworkname()+"uncomplete");
			  out.println("</p>");
			}else{
			   if(homework.getGrade()<60){
				   uncomplete++;
				   out.println("<p>");
					out.println(homework.getCoursename()+":"+homework.getHomeworkname()+"not pass");
				  out.println("</p>");
			   }
			}
		

		}
		if(uncomplete==0){
			   displayhomework(req,res);
		   }
		out.println("<input type='submit' name='Logout' value='Logout'>");
		out.println("</form>");

		out.println("总访问人数:"+sumofpeople);
	     out.println("已登录人数"+sumoflogin);
	     out.println("游客人数"+sumofcus);
		out.println("</body></html>");
	}

}
