package show.model;

public class Homework {
	private String username;	
	private String coursename;
	private String homeworkname;
	private Boolean complete;
	private double grade;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getHomeworkname() {
		return homeworkname;
	}
	public void setHomeworkname(String homeworkname) {
		this.homeworkname = homeworkname;
	}
	public Boolean getComplete() {
		return complete;
	}
	public void setComplete(Boolean complete) {
		this.complete = complete;
	}
	public double getGrade() {
		return grade;
	}
	public void setGrade(double grade) {
		this.grade = grade;
	}

}
