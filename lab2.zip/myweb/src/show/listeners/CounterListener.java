package show.listeners;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class CounterListener
 *
 */
@WebListener
public class CounterListener implements ServletContextListener, ServletContextAttributeListener {
	int sumofpeople;
	int sumoflogin;
	int sumofcus;
	String counterFilePath= "/Users/dongchenchen/Documents/webproject/myweb/WebContent/counter.txt";
    /**
     * Default constructor. 
     */
    public CounterListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent cse) {
    	try {
    		System.out.println("Reading Start"); 
    		System.out.println(counterFilePath);
    		BufferedReader reader = new BufferedReader(new FileReader(counterFilePath));
    		sumofpeople = Integer.parseInt( reader.readLine() );
    		sumoflogin=Integer.parseInt( reader.readLine() );
    		sumofcus=Integer.parseInt( reader.readLine() );
    		reader.close();
    		System.out.println("Reading总人数" + sumofpeople);
    		System.out.println("Reading总登录人数" + sumoflogin);
    		System.out.println("Reading总游客人数" + sumofcus);
    		}
    	catch (Exception e) {
    		System.out.println(e.toString());
    	}
    	ServletContext servletContext= cse.getServletContext();
    	servletContext.setAttribute("sumofpeople", Integer.toString(sumofpeople));
    	servletContext.setAttribute("sumoflogin", Integer.toString(sumoflogin));
    	servletContext.setAttribute("sumofcus", Integer.toString(sumofcus));
    	System.out.println("Application initialized");
    }

	/**
     * @see ServletContextAttributeListener#attributeAdded(ServletContextAttributeEvent)
     */
    public void attributeAdded(ServletContextAttributeEvent arg0) {
    	System.out.println("ServletContextattribute added");
    }

	/**
     * @see ServletContextAttributeListener#attributeReplaced(ServletContextAttributeEvent)
     */
    public void attributeReplaced(ServletContextAttributeEvent scae) {
    	System.out.println("ServletContextattribute replaced");
    	writeCounter(scae);
    }

	/**
     * @see ServletContextAttributeListener#attributeRemoved(ServletContextAttributeEvent)
     */
    public void attributeRemoved(ServletContextAttributeEvent arg0) {
    	System.out.println("ServletContextattribute removed");
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0) {
    	System.out.println("Application shut down");
    }
	/*
	 * servletContext.setAttribute("sumofpeople", Integer.toString(sumofpeople));
    	servletContext.setAttribute("sumoflogin", Integer.toString(sumoflogin));
    	servletContext.setAttribute("sumofcus", Integer.toString(sumofcus));
	 */
    synchronized void writeCounter(ServletContextAttributeEvent scae) {
    	ServletContext servletContext= scae.getServletContext();
    	sumofpeople = Integer.parseInt((String) servletContext.getAttribute("sumofpeople"));
    	sumoflogin = Integer.parseInt((String) servletContext.getAttribute("sumoflogin"));
    	sumofcus = Integer.parseInt((String) servletContext.getAttribute("sumofcus"));
    	try {
    		BufferedWriter writer = new BufferedWriter(new FileWriter(counterFilePath));
    		writer.write(Integer.toString(sumofpeople));
    		writer.newLine();
    		writer.write(Integer.toString(sumoflogin));
    		writer.newLine();
    		writer.write(Integer.toString(sumofcus));
    		writer.newLine();
    		writer.close();
    		System.out.println("Writing");
    	}catch (Exception e) {
    		System.out.println(e.toString());
    	}
    }
}
